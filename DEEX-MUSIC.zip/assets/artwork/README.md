Replace cover-01.png through cover-04.png with your own original/licensed artwork. Keep moderate dimensions (e.g. 1024x1024) for performance.

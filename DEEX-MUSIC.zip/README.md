# DEEX MUSIC
Production-oriented native Android music player architecture using Expo SDK 57 + React Native 0.86 + TypeScript + expo-audio.

## What is implemented
- Native Android app architecture (not WebView/PWA)
- Expo Router navigation: Home/Search/Library + full-screen Player/Playlists/Profile/Settings
- Native audio via `expo-audio`
- Android background playback + lock-screen/media notification configuration
- Local bundled demo audio
- Search + local search history
- Favorites persistence
- Playlist create/open/add/play persistence
- Recently played persistence
- Mini player + full player
- Seek, previous/next, shuffle, repeat one/all
- Local profile/settings
- Download abstraction ready for V2
- AdService abstraction separated from playback
- Graceful no-song states

## Install
```bash
npm install
npx expo start
```

## Android development
```bash
npx expo run:android
```
This requires Android SDK/ADB and a native build environment (normally a computer). Expo Go cannot reproduce every native production behavior because background media configuration and future ad SDK integration require a development/release build.

## EAS cloud build
Install/login:
```bash
npm install -g eas-cli
eas login
eas build:configure
```
Then:
```bash
eas build -p android --profile preview
eas build -p android --profile production
```
Use the preview build for an installable APK. Production normally produces an AAB for Play Console.

## Phone-only workflow
From an Android phone, Expo Go can be used for UI work with `npx expo start`, but native background audio and release APK/AAB builds should use EAS cloud builds. You can edit the project in a mobile code editor and upload/push it to a cloud build workflow.

## Demo audio
Original generated demo WAV files are under `assets/music/`. Replace them with original/licensed tracks and update `src/data/songs.ts`.

## Artwork/icon
Replace `assets/artwork/cover-01.png` etc. with original/licensed artwork. Replace `assets/artwork/icon-foreground.png` for the Android adaptive icon foreground. For a custom splash, add a splash image and configure `expo-splash-screen` in `app.json`.

## Ads
`src/services/AdService.ts` is deliberately isolated. V1 keeps ads disabled so the app remains fully buildable without credentials. For production ads, integrate a supported native SDK such as `react-native-google-mobile-ads` in an Expo development/release build, use Google's test interstitial IDs during development, store app/unit IDs in build-time configuration, and never place private server secrets in the APK. An ad failure must never block playback.

## Backend migration
Replace `src/services/MusicService.ts` with a Supabase/Firebase/custom API adapter without changing screen components. Keep remote audio on HTTPS and validate metadata before rendering.

## Verification
Run:
```bash
npm run typecheck
npx expo config --type public
```
For a real-device acceptance pass, also run the Android build and manually test background playback, lock-screen controls, Bluetooth/headphones, interruption, restart persistence, playlists, favorites and no-data states.

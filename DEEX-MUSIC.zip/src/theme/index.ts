export {colors} from './colors';
export const spacing={xs:6,sm:10,md:16,lg:22,xl:30};
export const radius={sm:10,md:16,lg:24,pill:999};

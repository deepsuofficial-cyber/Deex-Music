import React,{createContext,useContext,useEffect,useMemo,useState} from 'react';
import {useAudioPlayer,useAudioPlayerStatus,setAudioModeAsync} from 'expo-audio';
import {Song,RepeatMode} from '../models/song';
import {Storage} from '../storage/Storage';
import {songs} from '../data/songs';
import {AdService} from '../services/AdService';
type Ctx={current:Song|null;playing:boolean;time:number;duration:number;queue:Song[];shuffle:boolean;repeat:RepeatMode;playSong:(s:Song,list?:Song[])=>Promise<void>;toggle:()=>void;next:()=>Promise<void>;previous:()=>Promise<void>;seek:(n:number)=>Promise<void>;toggleShuffle:()=>void;cycleRepeat:()=>void;setQueue:(q:Song[])=>void};
const PlayerContext=createContext<Ctx|null>(null);
export function PlayerProvider({children}:{children:React.ReactNode}){
 const [current,setCurrent]=useState<Song|null>(null); const [queue,setQueue]=useState<Song[]>(songs); const [shuffle,setShuffle]=useState(false); const [repeat,setRepeat]=useState<RepeatMode>('off');
 const player=useAudioPlayer(null,{updateInterval:250}); const status=useAudioPlayerStatus(player);
 useEffect(()=>{setAudioModeAsync({playsInSilentMode:true,shouldPlayInBackground:true,interruptionMode:'doNotMix'}).catch(()=>{});AdService.initialize();},[]);
 useEffect(()=>{if(status.didJustFinish && current) next();},[status.didJustFinish,current]);
 const playSong=async(s:Song,list?:Song[])=>{try{await AdService.showInterstitial(); if(list)setQueue(list);setCurrent(s);player.replace(s.audio);player.setActiveForLockScreen(true,{title:s.title,artist:s.artist,albumTitle:s.album});player.play();const recent=await Storage.getRecent();await Storage.setRecent([s.id,...recent.filter(x=>x!==s.id)].slice(0,30));await Storage.setPlayback({songId:s.id});}catch(e){console.warn('Playback failed',e);}};
 const next=async()=>{if(!current)return;const list=queue.length?queue:songs;let i=list.findIndex(s=>s.id===current.id);let n=shuffle?Math.floor(Math.random()*list.length):i+1;if(n>=list.length){if(repeat==='all')n=0;else return;}if(repeat==='one'){player.seekTo(0);player.play();return;}await playSong(list[n],list);};
 const previous=async()=>{if(!current)return; if(status.currentTime>3){await player.seekTo(0);return;}const i=queue.findIndex(s=>s.id===current.id);await playSong(queue[Math.max(0,i-1)]??current,queue);};
 const value=useMemo(()=>({current,playing:status.playing,time:status.currentTime,duration:status.duration||current?.duration||0,queue,shuffle,repeat,playSong,toggle:()=>status.playing?player.pause():player.play(),next,previous,seek:(n:number)=>player.seekTo(n),toggleShuffle:()=>setShuffle(v=>!v),cycleRepeat:()=>setRepeat(v=>v==='off'?'all':v==='all'?'one':'off'),setQueue}),[current,status.playing,status.currentTime,status.duration,queue,shuffle,repeat]);
 return <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>;
}
export const usePlayer=()=>{const v=useContext(PlayerContext);if(!v)throw new Error('usePlayer must be inside PlayerProvider');return v;};
